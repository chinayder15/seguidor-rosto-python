# seguidor-de-rosto
projeto seguidor de rosto com python e arduino

Nesse codigo foi utilizado um arduino uno com 2 servos motores montados em um suporte de impressão 3D simulando uma câmera.

Na IDE do arduino, foi baixado a biblioteca Firmata (by Firmata Developers) diretamente da IDE do arduino.

Qualque dúvida entre em contato comigo no linkedin: https://www.linkedin.com/in/alerrandro-souza-61016a122?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base_contact_details%3BRtQyY8BxTJirtkkHCGLXcA%3D%3D
